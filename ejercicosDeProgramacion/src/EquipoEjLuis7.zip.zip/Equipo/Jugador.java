package Equipo;
public class Jugador {
    private String nombre;
    private String posicion;
    private int habilidad;


    public Jugador(String nombre, String posicion, int habilidad) {
        this.nombre = nombre;
        this.posicion = posicion;
        this.habilidad = habilidad;
    }
}